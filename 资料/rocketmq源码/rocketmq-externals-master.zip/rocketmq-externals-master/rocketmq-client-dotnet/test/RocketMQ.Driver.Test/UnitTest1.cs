using Xunit;

namespace RocketMQ.Driver.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
