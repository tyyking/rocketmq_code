#!/bin/bash

# Produce messages
docker exec -ti rmqbroker sh ./tools.sh org.apache.rocketmq.example.quickstart.Producer